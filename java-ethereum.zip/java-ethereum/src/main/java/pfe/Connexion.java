package pfe;

import io.reactivex.Flowable;
import io.reactivex.functions.Function;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.ens.contracts.generated.PublicResolver.ABIChangedEventResponse;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteCall;
//import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.request.EthFilter;
import org.web3j.protocol.core.methods.response.*;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.8.4.
 */
@SuppressWarnings("rawtypes")
public class Connexion extends Contract {
    public static final String BINARY = "608060405234801561001057600080fd5b5060008054600160a060020a0319163317905561091c806100326000396000f3fe608060405234801561001057600080fd5b506004361061009a576000357c01000000000000000000000000000000000000000000000000000000009004806380ca32021161007857806380ca3202146100ee57806397de0f0814610103578063a3bf241f14610116578063e6e862471461012957600080fd5b8063185f343e1461009f5780635f629471146100c857806370aca6c8146100db575b600080fd5b6100b26100ad36600461063b565b61013c565b6040516100bf91906107ac565b60405180910390f35b6100b26100d636600461063b565b610207565b6100b26100e936600461063b565b61024d565b6101016100fc366004610676565b610291565b005b6100b261011136600461063b565b610449565b6100b261012436600461063b565b61048f565b6100b261013736600461063b565b6104d5565b600054606090600160a060020a0316331461015657600080fd5b6001826040516101669190610790565b9081526020016040518091039020600301805461018290610863565b80601f01602080910402602001604051908101604052809291908181526020018280546101ae90610863565b80156101fb5780601f106101d0576101008083540402835291602001916101fb565b820191906000526020600020905b8154815290600101906020018083116101de57829003601f168201915b50505050509050919050565b600054606090600160a060020a0316331461022157600080fd5b6001826040516102319190610790565b9081526020016040518091039020600501805461018290610863565b600054606090600160a060020a0316331461026757600080fd5b6001826040516102779190610790565b908152604051908190036020019020805461018290610863565b600054600160a060020a031633146102a857600080fd5b856001846040516102b99190610790565b908152602001604051809103902060000190805190602001906102dd92919061051b565b50846001846040516102ef9190610790565b9081526020016040518091039020600101908051906020019061031392919061051b565b50836001846040516103259190610790565b9081526020016040518091039020600201908051906020019061034992919061051b565b508260018460405161035b9190610790565b9081526020016040518091039020600301908051906020019061037f92919061051b565b50816001846040516103919190610790565b908152602001604051809103902060040190805190602001906103b592919061051b565b50806001846040516103c79190610790565b908152602001604051809103902060050190805190602001906103eb92919061051b565b50826040516103fa9190610790565b60405180910390207fb0c004b083bdeb3a923635eb7aeaf1b6af835b070b573ce3efb607a9ee85e51e87878786866040516104399594939291906107c6565b60405180910390a2505050505050565b600054606090600160a060020a0316331461046357600080fd5b6001826040516104739190610790565b9081526020016040518091039020600101805461018290610863565b600054606090600160a060020a031633146104a957600080fd5b6001826040516104b99190610790565b9081526020016040518091039020600201805461018290610863565b600054606090600160a060020a031633146104ef57600080fd5b6001826040516104ff9190610790565b9081526020016040518091039020600401805461018290610863565b82805461052790610863565b90600052602060002090601f016020900481019282610549576000855561058f565b82601f1061056257805160ff191683800117855561058f565b8280016001018555821561058f579182015b8281111561058f578251825591602001919060010190610574565b5061059b92915061059f565b5090565b5b8082111561059b57600081556001016105a0565b600082601f8301126105c4578081fd5b813567ffffffffffffffff808211156105df576105df6108b7565b604051601f8301601f19908116603f01168101908282118183101715610607576106076108b7565b8160405283815286602085880101111561061f578485fd5b8360208701602083013792830160200193909352509392505050565b60006020828403121561064c578081fd5b813567ffffffffffffffff811115610662578182fd5b61066e848285016105b4565b949350505050565b60008060008060008060c0878903121561068e578182fd5b863567ffffffffffffffff808211156106a5578384fd5b6106b18a838b016105b4565b975060208901359150808211156106c6578384fd5b6106d28a838b016105b4565b965060408901359150808211156106e7578384fd5b6106f38a838b016105b4565b95506060890135915080821115610708578384fd5b6107148a838b016105b4565b94506080890135915080821115610729578384fd5b6107358a838b016105b4565b935060a089013591508082111561074a578283fd5b5061075789828a016105b4565b9150509295509295509295565b6000815180845261077c816020860160208601610833565b601f01601f19169290920160200192915050565b600082516107a2818460208701610833565b9190910192915050565b6020815260006107bf6020830184610764565b9392505050565b60a0815260006107d960a0830188610764565b82810360208401526107eb8188610764565b905082810360408401526107ff8187610764565b905082810360608401526108138186610764565b905082810360808401526108278185610764565b98975050505050505050565b60005b8381101561084e578181015183820152602001610836565b8381111561085d576000848401525b50505050565b60028104600182168061087757607f821691505b602082108114156108b1577f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b50919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fdfea264697066735822122058cccdae4660ab603f0c1eac8a747b754f1dcc4e4b8e173349a8ef6dfb2f7da364736f6c63430008040033";

    public static final String FUNC_GETHASHALGO = "getHashAlgo";

    public static final String FUNC_GETID = "getID";

    public static final String FUNC_GETMSID = "getMsid";

    public static final String FUNC_GETUID = "getUid";

    public static final String FUNC_GETUPSWD = "getUpswd";

    public static final String FUNC_GETX = "getX";

    public static final String FUNC_SETIDENTIFIERS = "setIdentifiers";

    public static final Event CREATE_EVENT = new Event("create", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>(true) {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
    ;

    @Deprecated
    protected Connexion(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Connexion(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Connexion(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Connexion(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public List<CreateEventResponse> getCreateEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(CREATE_EVENT, transactionReceipt);
        ArrayList<CreateEventResponse> responses = new ArrayList<CreateEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            CreateEventResponse typedResponse = new CreateEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.msid = (byte[]) eventValues.getIndexedValues().get(0).getValue();
            typedResponse.id = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.X = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.uid = (String) eventValues.getNonIndexedValues().get(3).getValue();
            typedResponse.upswd = (String) eventValues.getNonIndexedValues().get(4).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<CreateEventResponse> createEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new Function<Log, CreateEventResponse>() {
            @Override
            public CreateEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(CREATE_EVENT, log);
                CreateEventResponse typedResponse = new CreateEventResponse();
                typedResponse.log = log;
                typedResponse.msid = (byte[]) eventValues.getIndexedValues().get(0).getValue();
                typedResponse.id = (String) eventValues.getNonIndexedValues().get(0).getValue();
                typedResponse.X = (String) eventValues.getNonIndexedValues().get(1).getValue();
                typedResponse.hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
                typedResponse.uid = (String) eventValues.getNonIndexedValues().get(3).getValue();
                typedResponse.upswd = (String) eventValues.getNonIndexedValues().get(4).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<CreateEventResponse> createEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(CREATE_EVENT));
        return createEventFlowable(filter);
    }

    public RemoteCall<String> getHashAlgo(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETHASHALGO, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getID(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getMsid(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETMSID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUid(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUpswd(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUPSWD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getX(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETX, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> setIdentifiers(String _id, String _X, String _hashAlgo, String _msid, String _uid, String _upswd) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(
                FUNC_SETIDENTIFIERS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_id), 
                new org.web3j.abi.datatypes.Utf8String(_X), 
                new org.web3j.abi.datatypes.Utf8String(_hashAlgo), 
                new org.web3j.abi.datatypes.Utf8String(_msid), 
                new org.web3j.abi.datatypes.Utf8String(_uid), 
                new org.web3j.abi.datatypes.Utf8String(_upswd)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    @Deprecated
    public static Connexion load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connexion(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Connexion load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connexion(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Connexion load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Connexion(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Connexion load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Connexion(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Connexion> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connexion.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<Connexion> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connexion.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connexion> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connexion.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connexion> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connexion.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }

    public static class CreateEventResponse extends ABIChangedEventResponse{
        public byte[] msid;

        public String id;

        public String X;

        public String hashAlgo;

        public String uid;

        public String upswd;
    }
}