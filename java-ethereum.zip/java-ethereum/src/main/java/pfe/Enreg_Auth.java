/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

/**
 *
 * @author mounir
 */
public class Enreg_Auth  {
    Passerelle pas;
    Capteur cap;
    Utilisateur user;
    Connection_gen generator;
    int where = 0;
    char attack = '0';
    public Enreg_Auth (Passerelle pas, Capteur cap, Utilisateur user, Connection_gen generator,char attack, int where){
        this.pas=pas;
        this.cap = cap;
        this.user = user;
        this.generator=generator;
        this.attack = attack;
        this.where = where;
        
    }
    public String enregistrement (Capteur cap, Passerelle pas, Utilisateur user){
        
        return null;
    }
    public String[]  Auth (){
    	String[] affichage = new String[5];
        String capt = null,pasr = null, util = null,rcv = null,attaque = null;
        String msg1 = null, msg2 = null, msg3 = null, msg4 = null,titre = "";
        capt = cap.authMsg1(user);
        capt = capt+"\n"+cap.authMsg2(user);
        //envoi!
        msg1 = "MSID = "+cap.getMSID()+"<br>"+" N = "+user.getN()+"<br>"+"Un hash = "+user.getReceived_h();
        if (attack == 'm' && where == 1) {
        	titre = "Attaque détecté";
        	attaque = "<html><body>Message intercepté contient : "+"<br>"+msg1+"<br>"+"L'attaquant a reçu 2 valeurs de hach et une valeur aléatoire,"+"<br"+" Le système ne subira aucun problème</body></htmel>";
        	//System.out.println("message intercepté contient MSID = "+cap.getMSID()+" N = "+user.getN()+" un hash = "+user.getReceived_h()+"\n"+"l'attaquant a reçu 2 valeurs de hach et une valeur aléatoire, le système ne subira aucun problème");
        }
        
        util = user.authMsg2(cap,pas);
        rcv = user.authMsg3(cap,pas);
        if (rcv.equals("connexion éhoué")) {
        	
        	capt = "Authentification éhoué";
			pasr = "Authentification éhoué";
			util = "Authentification éhoué";
        }else {
        	
        	util = util+"\n"+rcv;
        	util = util+"\n"+user.authMsg4(cap,pas);
        	util = util+"\n"+user.authMsg5(cap,pas);
        	// envoi
        	msg2 = "MSID = "+cap.getMSID()+"<br>"+" N = "+pas.getN()+"<br>"+" M = "+pas.getM()+"<br>"+"Un hash = "+pas.getReceived_h()+"\n";
        	if (attack == 'm' && where == 2) {
        		titre = "Attaque détecté";
            	attaque = "<html><body>Message intercepté contient : "+"<br>"+msg2+"<br>"+"L'attaquant a reçu deux valeurs de hach et deux valeurs aléatoire,"+"<br>"+" Le système ne subira aucun problème</body></htmel>";
            	//System.out.println("message intercepté contient MSID = "+cap.getMSID()+" N = "+user.getN()+" un hash = "+user.getReceived_h()+"\n"+"l'attaquant a reçu 2 valeurs de hach et une valeur aléatoire, le système ne subira aucun problème");
            }
        	
        	pasr = pas.authMsg5(user);
        	pasr = pasr+"\n"+pas.authMsg6(user);
        	rcv = pas.authMsg7(user);
        	if (rcv.equals("connexion éhoué")) {            	
        		capt = "Authentification éhoué";
    			pasr = "Authentification éhoué";
    			util = "Authentification éhoué";
            }else {            	
            	pasr = pasr+"\n"+rcv;
            	pasr = pasr+"\n"+pas.authMsg8(user);
            	//envoi
            	msg3 =  "N = "+user.getN()+"<br>"+" M = "+user.getM()+"<br>"+" T = "+user.getT()+"<br>"+"Un hash = "+user.getReceived_h();
            	if (attack == 'm' && where == 3) {
            		titre = "Attaque détecté";
                	attaque = "<html><body>Message intercepté contient : "+"<br>"+msg3+"<br>"+"L'attaquant a reçu une valeur de hach et trois valeurs aléatoire,"+"<br>"+" Le système ne subira aucun problème</body></htmel>";
                	//System.out.println("message intercepté contient MSID = "+cap.getMSID()+" N = "+user.getN()+" un hash = "+user.getReceived_h()+"\n"+"l'attaquant a reçu 2 valeurs de hach et une valeur aléatoire, le système ne subira aucun problème");
                }
            	
            	util = util+"\n"+user.authMsg8(cap,pas);
            	rcv = user.authMsg9(cap,pas);
            	if (rcv.equals("connexion éhoué")) {
            		
            		capt = "Authentification éhoué";
        			pasr = "Authentification éhoué";
        			util = "Authentification éhoué";
            	}else {            	
            		util = util+"\n"+rcv;
            		util = util+"\n"+user.authMsg10(cap,pas);
            		//envoi
            		msg4 = "N = "+cap.getN()+"<br>"+" Z = "+cap.getZ()+"<br>"+" S = "+cap.getS()+"<br>"+"Un hash = "+cap.getReceived_h();
            		if (attack == 'm' && where == 4) {
            			titre = "Attaque détecté";
                    	attaque = "<html><body>Message intercepté contient : "+"<br>"+msg4+"<br>"+"L'attaquant a reçu une valeur de hach et trois valeurs aléatoire,"+"<br>"+" Le système ne subira aucun problème</body></htmel>";
                    	//System.out.println("message intercepté contient MSID = "+cap.getMSID()+" N = "+user.getN()+" un hash = "+user.getReceived_h()+"\n"+"l'attaquant a reçu 2 valeurs de hach et une valeur aléatoire, le système ne subira aucun problème");
                    }
            		
            		capt = capt+"\n"+cap.authMsg10(user);
            		util = util+"\n"+user.authMsg11(cap,pas);
            		rcv = cap.authMsg12(user);
            		if (rcv.equals("connexion éhoué")) {
            			
            			capt = "Authentification éhoué";
            			pasr = "Authentification éhoué";
            			util = "Authentification éhoué";
            		}else {            	
            			capt = capt+"\n"+rcv;
            		}
            	}
            }
        }
        if (attack == 'r' && where == 1) {
        	titre = "Attaque détecté";
        	attaque = "<html><body>Message renvoyé au utilisateur contient : "+"<br>"+msg1+"<br>"+"Les valeur envoyé seront enregistré mais écrasées avec l'authentification suivante,"+"<br>"+"Le system ne subira aucun problème</body></htmel>";
        } else if (attack == 'r' && where == 2) {
        	titre = "Attaque détecté";
        	attaque = "<html><body>Message renvoyé à la passerelle contient : "+"<br>"+msg2+"<br>"+"Les valeur envoyé seront enregistré mais écrasées avec l'authentification suivante,"+"<br>"+"Le system ne subira aucun problème</body></htmel>";
        } else if (attack == 'r' && where == 3) {
        	titre = "Attaque détecté";
        	attaque = "<html><body>Message renvoyé au utilisateur contient : "+"<br>"+msg3+"<br>"+"Les valeur envoyé seront enregistré mais écrasées avec l'authentification suivante,"+"<br>"+"Le system ne subira aucun problème</body></htmel>";
        } else if (attack == 'r' && where == 4) {
        	titre = "Attaque détecté";
        	attaque = "<html><body>Message renvoyé au capteur contient : "+"<br>"+msg4+"<br>"+"Les valeur envoyé seront enregistré mais écrasées avec l'authentification suivante,"+"<br>"+"Le system ne subira aucun problème</body></htmel>";
        } 
        if (attack != 'r' && attack != 'm') attaque  = "";
        System.out.println(attaque);
        
        affichage[0] = capt;
        affichage[1] = util;
        affichage[2] = pasr;
        affichage[3] = attaque;
        affichage[4] = titre;
        return affichage;
    }
    public String[] Enreg (){
    	String[] affichage = new String[3];
        System.out.println("hello there");
        String capt = null,pasr = null, util = null;
        capt = cap.enregMsg1(pas);
        util = user.enregMsg2(pas);
        pasr = pas.enregMsg1(cap, user);
        pasr = pasr + "\n" +pas.enregMsg2(cap, user);
        pasr = pasr + "\n" +pas.enregMsg3(cap, user);
        pasr = pasr + "\n" +pas.enregMsg4(cap, user);
        util = util + "\n" +user.enregMsg4(pas);
        util = util + "\n" +user.enregMsg5(pas);
        pasr = pasr + "\n" +pas.enregMsg5(cap, user);
        pasr = pasr + "\n" +pas.enregMsg6(cap, user);
        capt = capt + "\n" +cap.enregMsg6(pas);
        System.out.println("capt = "+capt);
        System.out.println("pasr = "+pasr);
        System.out.println("util = "+util);
        affichage[0] = capt;
        affichage[1] = pasr;
        affichage[2] = util;
        return affichage;
    }
    // 1 - Capteur envoie le ID;
    
    //2 - utllisateur envoie uid,upswd;
    //3 - passerelle enregistre les identifiants;
    //4 - passerelle envoie addr au utilisateur
    //5 - terminé 
    //6 - terminé
    
    
    
}
