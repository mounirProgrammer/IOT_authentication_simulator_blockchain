/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import javax.swing.JTextArea;

/**
 *
 * @author mounir
 */
public class Pas_thread implements Runnable {
    Passerelle pas;
    Utilisateur user;
    Capteur cap;
    char e_or_a;
    JTextArea area;
    public Pas_thread(Passerelle pas, Capteur cap, Utilisateur user, char e_or_a, JTextArea area){
        this.pas=pas;
        this.user=user;
        this.cap=cap;
        this.e_or_a=e_or_a;
        this.area = area;
    }
    public void run (){
        if(e_or_a == 'e'){
            
            area.setText(pas.enregistrement(cap,user));
            System.out.println(pas.enregistrement(cap,user));
        }else if (e_or_a == 'a'){
            
            area.setText(pas.authentification(user));
            System.out.println(pas.authentification(user));
        }
    }
    
}
