package pfe;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class HASHES {
    static public  String md5Hash(String clear) {
    	String generatedHash = null;
        try {
            // Create MessageDigest instance for 
            MessageDigest md = MessageDigest.getInstance("md5");
            //Get the hash's bytes 
            byte[] bytes = md.digest(clear.getBytes());
            //This bytes[] has bytes in decimal format;
            //Convert it to hexadecimal format
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < bytes.length; i++) {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get the complete hash in hex format
            generatedHash = sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return generatedHash;
    }
    static public String shaHash (String clear) {
    	String generatedHash = null;
    	
    	try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] bytes = md.digest(clear.getBytes());
            StringBuilder sb = new StringBuilder();
            for(int i=0; i< bytes.length ;i++)
            {
                sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
            }
            generatedHash = sb.toString();
        } 
        catch (NoSuchAlgorithmException e) 
        {
            e.printStackTrace();
        }
    	return generatedHash;
    }
    public static String PBKDF2Hash (String clear) {
    	int iterations = 1000;
        char[] chars = clear.toCharArray();
        byte[] hash = null;
        String toReturn = null;
        try {
        byte[] salt = getSalt();
        PBEKeySpec spec = new PBEKeySpec(chars, salt, iterations, 64 * 8);
        SecretKeyFactory skf;
			skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			hash = skf.generateSecret(spec).getEncoded();
			toReturn = iterations + ":" + toHex(salt) + ":" + toHex(hash);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return toReturn;

    }
    private static byte[] getSalt() throws NoSuchAlgorithmException {
       // SecureRandom sr = SecureRandom.getInstance("SHA1PRNG");
       // byte[] salt = new byte[16];
       // sr.nextBytes(salt);
       // return salt;
    	byte[] salt ={'1','2','3','4','5','6'}; 
    	return salt;
    }
    private static String toHex(byte[] array) throws NoSuchAlgorithmException
    {
        BigInteger bi = new BigInteger(1, array);
        String hex = bi.toString(16);
        int paddingLength = (array.length * 2) - hex.length();
        if(paddingLength > 0)
        {
            return String.format("%0"  +paddingLength + "d", 0) + hex;
        }else{
            return hex;
        }
    }
    
    public static void main(String []args ) {
    	System.out.println(shaHash("lmvd"));
    	System.out.println(md5Hash("lmvd"));
    	System.out.println(PBKDF2Hash("lmsef"));
    	try {
			System.out.println(getSalt());
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    

}
