/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author mounir
 */
public class PFE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // TODO code application logic here
        //Utilisateur user = new Utilisateur("uid", "upswd");
        //Capteur cap = new Capteur("helo", "MD5", "hi");
//        Passerelle pass = new Passerelle();
  //      pass.enrigistrement(5000);
        //cap.enrigistrement("127.0.0.1", 5000);
        //user.enregistrement("127.0.0.1", 5000);
        //user.authentification(5001);
        //cap.authentication("1270.0.1", 5001);
        //pass.authentification("127.0.0.1", 5001);
        JTextArea field= new JTextArea();
        //Passerelle pas = new Passerelle("1","hi");
       // Utilisateur user= new Utilisateur("hello","hello","hi",1,"hi");
        Capteur cap = new Capteur("hello","md5","hi");
        //Thread t1 = new Thread(new Cap_thread(cap,pas,user,'a',field));
        //t1.start();
        //Thread t2 = new Thread(new Pas_thread(pas,cap,user,'a',field));
        //t2.start();
        //Thread t3 = new Thread(new User_thread(user,cap,pas,'a',field));
        //t3.start();
        
        
        
       

    }

}
