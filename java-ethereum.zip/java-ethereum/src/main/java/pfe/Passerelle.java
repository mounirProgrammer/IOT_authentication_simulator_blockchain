/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketImpl;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.FastRawTransactionManager;
import org.web3j.tx.TransactionManager;

/**
 *
 * @author mounir
 */
public class Passerelle {
    
    private String uid = null;
    private String upswd = null;
    private String id= null;
    private String X;
    private String MSID;
    Capteur cap;
    Utilisateur user;
    String finished = null;
    String received_h= null;
    String id_pas;
    Connection_gen generator;
    char msg8 = '0';

    public char getMsg8() {
		return msg8;
	}


	public void setMsg8(char msg8) {
		this.msg8 = msg8;
	}


	public void setReceived_h(String received_h) {
        this.received_h = received_h;
    }
	public String getReceived_h() {
		return received_h;
	}
	public String getMSID() {
		return MSID;
	}
    
    
    public void setFinished(String finished) {
        this.finished = finished;
    }

    public String getId_pas() {
        return id_pas;
    }

    public void setId_pas(String id_pas) {
        this.id_pas = id_pas;
    }
    

    public void setX(String X) {
        this.X = X;
    }
    private String msid = null;
    private String hashAlgo;
    private long N,M,S,T;

    public String getUid() {
        return uid;
    }

    public String getUpswd() {
        return upswd;
    }

    public String getId() {
        return id;
    }

    public String getMsid() {
        return msid;
    }

    public String getHashAlgo() {
        return hashAlgo;
    }

    public long getN() {
        return N;
    }

    public long getM() {
        return M;
    }

    public long getS() {
        return S;
    }

    public long getT() {
        return T;
    }

    

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setUpswd(String upswd) {
        this.upswd = upswd;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setMsid(String msid) {
        this.msid = msid;
    }

    public void setHashAlgo(String hashAlgo) {
        this.hashAlgo = hashAlgo;
    }

    public void setN(long N) {
        this.N = N;
    }

    public void setM(long M) {
        this.M = M;
    }

    public void setS(long S) {
        this.S = S;
    }

    public void setT(long T) {
        this.T = T;
    }
    
    
    
    
    
    
    
    
    public Passerelle(String id_pas,Connection_gen generator){
        this.id_pas=id_pas;
        this.generator=generator;

        
    }
    
    public String  enregistrement(Capteur cap, Utilisateur user){
        this.cap=cap;
        this.user=user;
       /* Serveur serveur =new Serveur(port);
        Thread serveur_thread = new Thread(serveur);
        serveur_thread.start();
        */
        
            
            
    String affichage = null; 
    //recevoir id,X,algoHash
    while(id==null){
        System.out.println("waiting");
    }
        
        System.out.println("1- id, X, alogorithme de hashage de capteur reçus");
        affichage ="message 1 reçu";
    //recevoir uid,upswd
    while(uid==null){
        System.out.println("waiting");
    }
        System.out.println("message 2 reçu");
        affichage = affichage+"\n"+"message 2 reçu";
    //calcule msid= h(id || X)
    MSID=H(id+X,hashAlgo);
    
    // Enregistrer id,X,algihash,msid,uid,upswd dans la blockchain
    generator.create_con(id, X, hashAlgo, MSID, uid, upswd);
    System.out.println("3- les identifiants de capteur et utilisateur sont  enregistré dans le reseau blockchain");
    affichage = affichage + "\n"+ "3- les identifiants de capteur et utilisateur sont  enregistré dans le reseau blockchain";
    affichage = affichage + "\n"+"msid =  "+MSID+"  getID =  "+generator.getID(MSID);
    //envoyer msid id x au utlisateur
    user.setID(id);
    user.setMSID(MSID);
    user.setAlgoHash(hashAlgo);
    user.setX(X);
    System.out.println("4- les identifiants de capteur et utilisateur sont envoyé au utilisateur");
    affichage = affichage +"\n"+"4- les identifiants de capteur et utilisateur sont envoyé au utilisateur";
    
    
    //recevoir finished from l'utilisateur
    while(finished == null){
        System.out.println("waiting");
    }
        System.out.println("passerelle "+ finished);
        affichage = affichage + "\n" + "message : "+finished+" reçu ";
        
    //envoyer finished au capteur
        cap.setCap_finished("terminé");
        affichage = affichage + "\n" + "message terminé envoyé au capteur";
        System.out.println("message terminé envoyé au capteur");
    
        return affichage;
    }
    
    public String authentification (Utilisateur user) {
        this.user=user;
        /*
        Client client;
        client = new Client(ip_address,port);
        Thread client_thread = new Thread(client);
        client_thread.start();
        */
        
        String h=null;
        String  affichage=null;
        // recevoir le msid,N,M,h(id, N, M)
        while(msid==null){
            System.out.print(" ");
        }
        System.out.println("message 5 (msid, N, M, h(id, N, M)) reçu");
        affichage= " - message 5 (msid, N, M, h(id, N, M)) reçus";
        //calculer h()
        // algoHash id from blockchain
        
        System.out.println("6- récupérer le id stocké dans la blockchain");
        affichage= affichage + "\n"+"6- récupérer le id stocké dans la blockchain id = "+generator.getID(msid);
        h=H(generator.getID(msid)+" "+ N+" "+ M, hashAlgo);
        //verifier le h()
        if(!h.equals(received_h)){
        	user.setMsg5('f');
            System.out.println("Connextion a echoué");
            affichage = affichage + "\n"+ "connection a echoué (h reçu et h calculé ne sont pas éguaux)";
            return affichage;
        }else user.setMsg5('v');
        //generer S;
        S=0;
        Random r = new Random();
        while (S <= 0) {
        	S = r.nextLong();	
        }
        //T= N ^ S
        T=0;
        T=N ^ S;
        System.out.println(" - générer S et T \n - S = "+S+"\n - T = N ^ S = "+T);
        affichage = affichage+"\n"+" - générer S et T \n - S = "+S+"\n - T = N ^ S = "+T;
        
        //calculer h() 
        //id algoHash from blockchain
        h=H(generator.getID(msid)+" "+M+" "+S,hashAlgo);
        //envoyer N,M,T,h(id,M,S) au passerelle
        user.setReceived_h(h);
        user.setN(N);
        user.setM(M);
        user.setT(T);
        /* 
        for(int i=0;i<19-String.format("%d", N).length();i++){
        n_str="0"+n_str;
        }
        String m_str =String.format("%d", M); 
        for(int i=0;i<19-String.format("%d", M).length();i++){
        m_str="0"+m_str;
        }
        String t_str =String.format("%d", T); 
        for(int i=0;i<19-String.format("%d", T).length();i++){
        t_str="0"+t_str;
        }
        */
        
        System.out.println("8- N, M, T, h(id, M, S) envoyé au utilisateur");
        affichage = affichage + "\n"+ "8- N, M, T, h(id, M, S) envoyé au utilisateur";
        while(msg8 == '0') {
        	System.out.println(" ");
        }
        if (msg8 == 'f') {
        	affichage = affichage + "\n"+"connxion echoué";
        	return affichage;
        }
        return affichage;
    }
    private String H(String clear, String algoHash) {
        String generatedHash = null;
        if (algoHash.equals("md5")) {
        	generatedHash = HASHES.md5Hash(clear);
        }else if (algoHash.equals("SHA-1") || algoHash.equals("SHA-256") || algoHash.equals("SHA-384") || algoHash.equals("SHA-512")) {
        	generatedHash = HASHES.shaHash(clear);
        }else if(algoHash.equals("PBKDF2")) {
        	generatedHash = HASHES.PBKDF2Hash(clear);
        }
        return generatedHash;
    }
    
    public static void main(String [] args){
        
        //Passerelle passerelle =new Passerelle();
       /* Scanner sc= new Scanner (System.in);
        String message =null;
        message = sc.next();
        serveur.send(message);
        String reçu=null;
       long t= System.currentTimeMillis();
       long time=t;
       //t=t+600000;
       t=t+10000;
       
       while(time < t){
           time = System.currentTimeMillis();
        //wait
       }
       */
       
    }
    public String enregMsg1 (Capteur cap, Utilisateur user){
        //recevoir les identifiants de l'utilisateur
        String affichage = null;
        System.out.println("message 2 reçu(les identifiants de l'utilisateur)");
        affichage = "  - message 1 reçu (les identifiants de capteur)";
        return affichage;
    }
    public String enregMsg2 (Capteur cap, Utilisateur user){
        //calculer msid et enregistre dans la blockchain
        String affichage = null;
        System.out.println(" - message 2 (les identifiants de l'utilisateur) reçu");
        affichage = "  - message 2 reçu (les identifiants de l'utilisateur)";
        return affichage;
    }
    public String enregMsg3 (Capteur cap, Utilisateur user){
        String affichage = null;
        //calcule msid= h(id || X)
        MSID=H(id+X,hashAlgo);
        generator.create_con(id, X, hashAlgo, MSID, uid, upswd);
        // Enregistrer id,X,algihash,msid,uid,upswd dans la blockchain
        System.out.println("3- les identifiants de capteur et utilisateur sont  enregistré dans le reseau blockchain");
        affichage = "3- Msid calculé et les identifiants de capteur et utilisateur sont  enregistré dans le reseau blockchain";
        affichage = affichage + "\n"+"  - msid =  "+MSID+" id dans blockchain = "+generator.getID(MSID);
        return affichage;
    }
    public String enregMsg4 (Capteur cap, Utilisateur user){
        String affichage = null;
        //envoyer msid id x au utlisateur
        //user.setID(id);
        ///user.setMSID(MSID);
        //user.setAlgoHash(hashAlgo);
        //user.setX(X);
        System.out.println("4- adresse de blockchain envoyé au utilisateur");
        affichage = "4- adresse de blockchain envoyé au utilisateur";
    
        return affichage;
    }
    public String enregMsg5 (Capteur cap, Utilisateur user){
        String affichage = null;
        //recevoir finished from l'utilisateur
        System.out.println("passerelle "+ finished);
        affichage = "  - message  5 '"+finished+"' reçu ";
        return affichage;
    }
    public String enregMsg6 (Capteur cap, Utilisateur user){
        String affichage = null;
        //envoyer finished au capteur
        cap.setCap_finished("terminé");
        System.out.println("6- message 'terminé' envoyé au capteur");
        affichage = "6- message terminé envoyé au capteur";
        return affichage;
    }
    

    String authMsg5(Utilisateur user) {
        String affichage = null;
        System.out.println("message 6 (msid, N, M, h()) reçu");
        affichage= "  - message 6 (msid, N, M, h()) reçus";
        
        return affichage;
    }

    String authMsg6(Utilisateur user) {
        String affichage = null;
        String h =null;
        System.out.println("7- récupérer le id stocké dans la blockchain");
        affichage= "7- récupérer le id stocké dans la blockchain \n  -  id = "+generator.getID(msid);
        
        
        return affichage;
    }

    String authMsg7(Utilisateur user) {
        String affichage = null;
        String h = null;
        h=H(generator.getID(msid)+" "+ N+" "+ M, hashAlgo);
        //verifier le h()
        if(!h.equals(received_h)){
            System.out.println("Connextion a echoué");
            affichage = "connection a echoué (h reçu et h calculé ne sont pas égaux)";
            return "connexion éhoué";
        }
        //generer S;
        S=0;
        Random r = new Random();
        while (S <= 0) {
        	S = r.nextLong();	
        }
        //T= N ^ S
        T=0;
        T=N ^ S;
        System.out.println("9  - générer S et T \n - S = "+S+"\n - T = N ^ S = "+T);
        affichage = "9 - générer S et T \n  - S = "+S+"\n  - T = N ^ S = "+T;
        
        return affichage;
    }

    String authMsg8(Utilisateur user) {
        String affichage = null;
        //envoyer N,M,T,h(id,M,S) au passerelle
        String h= null;
        h=H(generator.getID(msid)+" "+M+" "+S,hashAlgo);
        user.setReceived_h(h);
        user.setN(N);
        user.setM(M);
        user.setT(T);
        System.out.println("10- N, M, T, h() envoyé au utilisateur");
        affichage = "10- N, M, T, h() envoyé au utilisateur";
        return affichage;
    }

}
