/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import javax.swing.JTextArea;

/**
 *
 * @author mounir
 */
public class User_thread implements Runnable{
    Passerelle pas;
    Utilisateur user;
    Capteur cap;
    char e_or_a;
    JTextArea area;
    public User_thread(Utilisateur user, Capteur cap, Passerelle pas, char e_or_a,JTextArea area){
        this.pas=pas;
        this.user=user;
        this.cap=cap;
        this.e_or_a=e_or_a;
        this.area=area;
    }
    public void run (){
        System.out.println(e_or_a);
        if(e_or_a == 'e'){
            area.setText(user.enregistrement(pas));
            System.out.println(user.enregistrement(pas));
        }else if (e_or_a == 'a'){
            area.setText(user.authentification(pas,cap));
            System.out.println(user.authentification(pas,cap));
        }
    }
}
