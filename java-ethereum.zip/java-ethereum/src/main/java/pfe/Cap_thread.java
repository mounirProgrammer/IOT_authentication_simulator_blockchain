/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import javax.swing.JTextArea;

/**
 *
 * @author mounir
 */
public class Cap_thread implements Runnable{
    Passerelle pas;
    Utilisateur user;
    Capteur cap;
    char e_or_a;
    JTextArea area;
    public Cap_thread(Capteur cap,Passerelle pas,Utilisateur user, char e_or_a,JTextArea area){
        this.pas=pas;
        this.user=user;
        this.cap=cap;
        this.e_or_a=e_or_a;
        this.area=area;
    }
    public void run (){
        System.out.println(e_or_a);
        if(e_or_a == 'e'){
            area.setText(cap.enregistrement(pas));
            System.out.println(cap.enregistrement(pas));
        }else if (e_or_a == 'a'){
            area.setText(cap.authentication(user));
            System.out.println(cap.authentication(user));
        }
    }
}
