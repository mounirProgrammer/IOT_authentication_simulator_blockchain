/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

/**
 *
 * @author mounir
 */
public class Utilisateur {

    private String ID=null;
    private String AlgoHash="MD5";
    private String X;
    private String MSID=null;
    private String uid;
    private String upswd;
    long k1=0;
    long k2=0;
    String k = null; 
    String finished;
    Passerelle pas;
    Capteur cap;
    String received_h= null;
    Connection_gen generator;
    char  msg5 = '0';
    char msg10 = '0';
    
    
    

    public String getReceived_h() {
		return received_h;
	}

	public char getMsg10() {
		return msg10;
	}

	public void setMsg10(char msg10) {
		this.msg10 = msg10;
	}
    public char getMsg5() {
		return msg5;
	}

	public void setMsg5(char msg5) {
		this.msg5 = msg5;
	}

	public void setMsid(String msid) {
        this.MSID = msid;
    }

    public void setReceived_h(String received_h) {
        this.received_h = received_h;
    }
    

    public String getFinished() {
        return finished;
    }

    public void setFinished(String finished) {
        this.finished = finished;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setAlgoHash(String AlgoHash) {
        this.AlgoHash = AlgoHash;
    }

    public void setX(String X) {
        this.X = X;
    }

    public void setMSID(String MSID) {
        this.MSID = MSID;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setUpswd(String upwsd) {
        this.upswd = upwsd;
    }

    public void setN(long N) {
        this.N = N;
    }

    public void setM(long M) {
        this.M = M;
    }

    public void setT(long T) {
        this.T = T;
    }

    public void setS(long S) {
        this.S = S;
    }

    public void setZ(long Z) {
        this.Z = Z;
    }

    public void setW(long W) {
        this.W = W;
    }

    public String getID() {
        return ID;
    }

    public String getAlgoHash() {
        return AlgoHash;
    }

    public String getX() {
        return X;
    }

    public String getMSID() {
        return MSID;
    }

    public String getUid() {
        return uid;
    }

    public String getUpswd() {
        return upswd;
    }

    public long getN() {
        return N;
    }

    public long getM() {
        return M;
    }

    public long getT() {
        return T;
    }

    public long getS() {
        return S;
    }

    public long getZ() {
        return Z;
    }

    public long getW() {
        return W;
    }
    private long N,M,T = 0,S,Z,W;

    
    
    String ip_blockchain = "127.0.0.1";
    int port_blockchain = 8545;
    String address_blockchain = "0x09b8c0d8566e1a83c2156c37411c9726cb93867da0ae507d0eb2a594dd688ebf"; 
    

    public Utilisateur(String uid, String upswd, Connection_gen generator) {
        this.uid = uid;
        this.upswd = upswd;
        this.generator=generator;

    }
    

    public String enregistrement(Passerelle pas) {
        this.pas=pas;
        
       
        String affichage = null;
        /*
        Client client;
        String reception = null;
        client = new Client(ip_address, port);
        Thread client_thread = new Thread(client);
        client_thread.start();
        */
        // envoyer le uid, upswd au passerelle via une canal securisé
        pas.setUid(uid);
        pas.setUpswd(upswd);
        System.out.println("2- uid, upswd envoyé au passerelle");
        affichage = "2- uid, upswd envoyé au passerelle";
        // recever les identifiants de capteur
        while (ID == null) {
           System.out.print(" ");
        }
        System.out.println("message 3 reçu");
        affichage = affichage +"\n"+"message 3  reçu"+"\n"+"msid = "+MSID+" getID = "+generator.getID(MSID);
        //enregistrer les identifiants de capteur et utilisateur dans la blockchain
        
        
        System.out.println("5- les identifiants de capteur et utilisateur sont enregistré dans le reseau blockchain");
        affichage =affichage + "\n"+ "5- les identifiants de capteur et utilisateur sont enregistré dans le reseau blockchain";
        // envoyer un message "terminé au passerelle
        pas.setFinished("terminé");
        affichage = affichage + "\n" + "message terminé envoyé au passerelle";
        System.out.println("message terminé envoyé au passerelle");
    
        return affichage;
    }

    public String  authentification(Passerelle pas, Capteur cap) {
        this.pas=pas;
        this.cap=cap;
        String affichage = null;
        String h;
        /*
        Serveur serveur = new Serveur(port);
        Thread serveur_thread = new Thread(serveur);
        serveur_thread.start();
        */
        
        String reception = null;
        N = 0;
        
        //recevoir N, msid, h(id, msid, N) from le  noeud de capteur
        while (N == 0) {
            System.out.println(" ");
        }
        
        System.out.println("- message 2 (N, msid,h(id, msid, N)) reçu");
        affichage= " - message 2 (N, msid,h(id, msid, N)) reçu";
        
        
        //Long n = Long.parseLong(reception.substring(reception.indexOf('N') + 4, reception.indexOf('N') + 23));
        
        //calculer h()
        h = H(MSID+generator.getID(MSID)+N, AlgoHash);
        //verifier h
        if (!h.equals(received_h)) {
        	cap.setMsg2('f');
            System.out.println("h="+h+"\n"+"received h = "+received_h);
            System.out.println("Connextion a echoué");
            affichage = affichage + "\n"+"msid = "+MSID+"id = "+generator.getID(MSID)+"\n"+"connection a echoué (h reçu de capteur et h calculé ne sont pas eguaux)";
            return affichage;

        }else cap.setMsg2('v');
        
        //generer M
        M = 0; T = 0; S = 0; Z = 0; W = 0;
        Random r = new Random();
        while (M <= 0) {
        	M = r.nextLong();	
        }
        System.out.println(" - M = "+M);
        affichage = affichage + "\n"+ " - M = "+M;
        //calculer h
        h = H(generator.getID(MSID)+" "+ N+" "+ M, AlgoHash);
        //envoyer msid,N,M,h(id,N,M) au passerelle
        
        pas.setReceived_h(h);
        pas.setN(N);
        pas.setM(M);
        //pas.setId(ID);
        pas.setHashAlgo(AlgoHash);
        pas.setMsid(MSID);
        
        System.out.println(" 5- N, M, h(id, N,M) envoyé au passerelle");
        affichage= affichage +"\n" +"5- N, M, h(id, N,M) envoyé au passerelle";
        while(msg5 == '0') {
        	System.out.println(" ");
        }
        if (msg5 == 'f') {
        	affichage = affichage + "\n"+"connxion echoué";
        	return affichage;
        }
        //recevoir de N,M,T,h(id,M,S) from le passrelle
        
        while (T==0) {
            System.out.print(" ");
        }
        System.out.println(" message 8 (N, M, T, (h(id, M, S)) reçus");
        affichage= affichage +"\n" +" - message 8 (N, M, T, (h(id, M, S)) reçus";
        
        
//        T = Long.parseLong(reception.substring(reception.indexOf('T') + 4, reception.indexOf('T') + 23));

        //calculer S= N ^ T
        S = N ^ T;
        //calculer h
        h = H(generator.getID(MSID)+" "+M+" "+S, AlgoHash);
        //verifier h()
        if (!received_h.equals(h)) {
        	pas.setMsg8('f');
            System.out.println("Connextion a echoué (h reçu de passerelle et h calculé ne sont pas égqux)");
            affichage = affichage + "\n"+ "connection a echoué";
            return affichage;

        }else pas.setMsg8('v');
        //calculer Z = W ^ S
        while (W <= 0) {
        	W = r.nextLong();	
        }
        Z = W ^ S;
        System.out.println(" W = "+W+"\n"+" Z = "+Z);
        affichage =affichage + "\n" + " W = "+W+"\n"+" Z = "+Z;
        //envoyer N,Z,S, h(id, N,W) au capteur
        h=H(generator.getID(MSID)+" "+N+" "+W, AlgoHash);
        cap.setZ(Z);
        cap.setN(N);
        cap.setS(S);
        cap.setReceived_h(h);
        System.out.println("10- N, Z, S, h(id, N, W) envoyé au capteur");
        affichage= affichage +"\n" +"10- N, Z, S, h(id, N, W) envoyé au capteur";
        while(msg10 == '0') {
        	System.out.println(" ");
        }
        if (msg10 == 'f') {
        	affichage = affichage + "\n"+"connxion echoué";
        	return affichage;
        }
        //calculer k1 et k2 et k
        k1 = N ^ S;
        k2 = N ^ W;
        //k = f(enc(k1+k2),X))
        
        AES aes = new AES();
        k = aes.encrypt(k1+""+k2, X);
        k = H(k,"md5");
        System.out.println("k1 = "+k1+"\n k2 = "+k2+"\n k = "+k);
        affichage= affichage +"\n" +"k1 = "+k1+"\n k2 = "+k2+"\n k = "+k;
        return affichage;

    }

    private String H(String clear, String algoHash) {
        String generatedHash = null;
        if (algoHash.equals("md5")) {
        	generatedHash = HASHES.md5Hash(clear);
        }else if (algoHash.equals("SHA-1") || algoHash.equals("SHA-256") || algoHash.equals("SHA-384") || algoHash.equals("SHA-512")) {
        	generatedHash = HASHES.shaHash(clear);
        }else if(algoHash.equals("PBKDF2")) {
        	generatedHash = HASHES.PBKDF2Hash(clear);
        }
        return generatedHash;
    }


     
    
    

    public static void main(String[] args) {
        /*long Z=0000000000000012664;
       String z_str =String.format("%d", Z); 
                for(int i=0;i<19-String.format("%d", Z).length();i++){
                    z_str="0"+z_str;
                }
       System.out.println(z_str);
       //Utilisateur user = new Utilisateur("mounir","mounir");
         */
//        Capteur cap = new Capteur("helo", "MD5", "hi");
    }
    public String enregMsg2 (Passerelle pas){
        // envoyer le uid, upswd au passerelle via une canal securisé
        String affichage = null;
        pas.setUid(uid);
        pas.setUpswd(upswd);
        System.out.println("2- uid, upswd envoyé au passerelle");
        affichage = "2- uid, upswd envoyé au passerelle";
        return affichage;
    } 
    public String enregMsg4 (Passerelle pas){
        // recevoir l 'adresse
        String affichage = null;
        // envoyer le uid, upswd au passerelle via une canal securisé
        System.out.println("message 4 (l'adresse de bockchain) rreçu ");
        affichage = "  - message 4 (l'adresse de bockchain) reçu ";
        return affichage;
    }
    public String enregMsg5 (Passerelle pas){
        String affichage = null;
        pas.setFinished("terminé");
        affichage = "5 - message 'terminé' envoyé au passerelle";
        System.out.println("message terminé envoyé au passerelle");
    
        return affichage;
    }

    

    String authMsg2(Capteur cap, Passerelle pas) {
        String affichage = null;
        System.out.println("- message 2 (N, msid,h()) reçu");
        affichage= "  - message 2 (N, msid,h()) reçu";
        
        return affichage;
    }

    String authMsg3(Capteur cap, Passerelle pas) {
        String affichage = null;
        String h = null; 
        h = H(MSID+generator.getID(MSID)+N, AlgoHash);
        System.out.println("h(msid,id,n,algohash) = h("+MSID+" , "+generator.getID(MSID)+" , "+N+" , "+generator.getHashAlgo(MSID)+" = \n "+h);
        if (!h.equals(received_h)) {
            System.out.println("h="+h+"\n"+"received h = "+received_h);
            System.out.println("Connextion a echoué");
            affichage = "msid = "+MSID+"id = "+generator.getID(MSID)+"\n"+"connection a echoué (h reçu de capteur et h calculé ne sont pas eguaux) \n + gen address"+generator.getAdresse();
            //return affichage;
            return "connexion éhoué";

        }else affichage  = "3- ID recupéré, id = "+generator.getID(MSID);
        return affichage;
    }

    String authMsg4(Capteur cap, Passerelle pas) {
        String affichage = null;
        M = 0; T = 0; S = 0; Z = 0; W = 0;String h = null;
        Random r = new Random();
        while (M <= 0) {
        	M = r.nextLong();	
        }
        System.out.println(" - M = "+M);
        affichage = "5- vérifier h() et générer M "+"\n"+"  - M = "+M;
        //calculer h
        h = H(generator.getID(MSID)+" "+ N+" "+ M, AlgoHash);
        //envoyer msid,N,M,h(id,N,M) au passerelle
        
        pas.setReceived_h(h);
        pas.setN(N);
        pas.setM(M);
        //pas.setId(ID);
        pas.setHashAlgo(AlgoHash);
        pas.setMsid(MSID);
        return affichage;
    }

    String authMsg5(Capteur cap, Passerelle pas) {
        String affichage = null;
        System.out.println(" 6- N, M, h() envoyé au passerelle");
        affichage= "6- N, M, h() envoyé au passerelle";
        return affichage;
    }

    String authMsg8(Capteur cap, Passerelle pas) {
        String affichage = null;
        System.out.println(" message 10 (N, M, T, (h(id, M, S)) reçus");
        affichage= "  - message 10 reçu (N, M, T, (h())";
        return affichage;
    }

    String authMsg9(Capteur cap, Passerelle pas) {
        String affichage = null;
        String h = null;
        S = N ^ T;
        //calculer h
        h = H(generator.getID(MSID)+" "+M+" "+S, AlgoHash);
        //verifier h()
        if (!received_h.equals(h)) {
            System.out.println("Connextion a echoué (h reçu de passerelle et h calculé ne sont pas égqux)");
            affichage =  "connection a echoué";
            return "connexion éhoué";

        }
        //calculer Z = W ^ S
        Random r = new Random();
        while (W <= 0) {
        	W = r.nextLong();	
        }
        Z = W ^ S;
        System.out.println(" W = "+W+"\n"+" Z = "+Z);
        affichage ="11- h() vérifié, W,Z calculé: "+"\n"+"  - W = "+W+"\n"+"  - Z = "+Z;
        //envoyer N,Z,S, h(id, N,W) au capteur
        h=H(generator.getID(MSID)+" "+N+" "+W, AlgoHash);
        cap.setZ(Z);
        cap.setN(N);
        cap.setS(S);
        cap.setReceived_h(h);
        return affichage;
    }

    String authMsg10(Capteur cap, Passerelle pas) {
        String affichage = null;
        System.out.println("12- N, Z, S, h(id, N, W) envoyé au capteur");
        affichage= "12- N, Z, S, h() envoyé au capteur";
        return affichage;
    }

    String authMsg11(Capteur cap, Passerelle pas) {
        String affichage = null;
        k1 = N ^ S;
        k2 = N ^ W;
        //k = f(enc(k1+k2),X))
        
        AES aes = new AES();
        k = aes.encrypt(k1+""+k2, generator.getX(MSID));
        k = H(k,"md5");
        System.out.println("  - k1 = "+k1+"\n   - k2 = "+k2+"\n   - k = "+k);
        affichage= "13- clé de chiffrement 'k' calculé:"+"\n"+"  - k1 = "+k1+"\n   - k2 = "+k2+"\n   - k = "+k;

        return affichage;
    }


}
