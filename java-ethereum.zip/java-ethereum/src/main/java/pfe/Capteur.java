/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pfe;

import java.sql.Timestamp;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import javax.swing.JTextArea;

/**
 *
 * @author mounir
 */
public class Capteur {
    private String ID="hello";
    private String algoHash="MD5";
    private String X="hi";
    private String MSID=null;
    private long N=0,N1 =0,Z=0,S=0,W=0;
    private long k1,k2;
    String k;
    Passerelle pas;
    String cap_finished = null;
    String received_h = null;
    Utilisateur user;
    char msg2 ='0';
    

    public char getMsg2() {
		return msg2;
	}

	public void setMsg2(char msg2) {
		this.msg2 = msg2;
	}

	public void setReceived_h(String received_h) {
        this.received_h = received_h;
    }
	public String getReceived_h() {
		return received_h;
	}

    public void setCap_finished(String cap_finished) {
        this.cap_finished = cap_finished;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setAlgoHash(String algoHash) {
        this.algoHash = algoHash;
    }

    public void setX(String X) {
        this.X = X;
    }

    public void setMSID(String MSID) {
        this.MSID = MSID;
    }

    public void setN(long N) {
        this.N = N;
    }

    public void setZ(long Z) {
        this.Z = Z;
    }

    public void setS(long S) {
        this.S = S;
    }

    public void setW(long W) {
        this.W = W;
    }


    public String getID() {
        return ID;
    }

    public String getAlgoHash() {
        return algoHash;
    }

    public String getX() {
        return X;
    }

    public String getMSID() {
        return MSID;
    }

    public long getN() {
        return N;
    }

    public long getZ() {
        return Z;
    }

    public long getS() {
        return S;
    }

    public long getW() {
        return W;
    }

   
    
    public Capteur(String ID,String algoHash,String X){
        this.ID=ID;
        this.algoHash=algoHash;
        this.X=X;
        MSID=H(ID+X,algoHash);

    }
    
    public String enregistrement(Passerelle pas){
        this.pas=pas;
        //String reception= null;
        /*Client client;
        //client = new Client(ip_address,port);
        //Thread client_thread = new Thread(client);
        //client_thread.start();
        */
        String affichage = null;
        
        // envoyer le  id, hashAlgo, X au passerelle
        pas.setId(ID);
        pas.setHashAlgo(algoHash);
        pas.setX(X);
        
        
        //client.send("cap_enr_msg: id= "+ID+" algorithme de hashage = ");
        //client.send(algoHash+" X = "+X);
        
        
        System.out.println("1- le capteur a envoyé id, algorithme de hashage et la clé secrète au passerelle");
        affichage= "1- le capteur a envoyé id, algorithme de hashage et la clé secrète au passerelle";
        // recever le message
        while(cap_finished==null){
            System.out.println("waiting");
        }
        
        System.out.println("capteur"+cap_finished);
        affichage = affichage + "\n" + "message : "+cap_finished+" reçu l'enregistrement est terminé";
        return affichage;
    }
    public String authentication(Utilisateur user){
        this.user=user;
        /*Client client;
        client = new Client(ip_address,port);
        Thread client_thread = new Thread(client);
        client_thread.start();
        */
        
        String affichage=null;
        String h=null;
        long N1=0;
        N = 0;
        Random r = new Random();
        while (N1 <= 0) {
        	N1 = r.nextLong();	
        }
        
        MSID=H(ID+X,algoHash);
        h=H(MSID+ID+N1,algoHash);
        System.out.println("1- N généré"+"\n"+"  - N = "+N1);
        affichage ="1- N généré"+"\n"+"  - N = "+N1;
        //send the infos
        /*String n_str =String.format("%d", N); 
                for(int i=0;i<19-String.format("%d", N).length();i++){
                    n_str="0"+n_str;
                }
        */
        user.setN(N1);
        user.setReceived_h(h);
        //user.setID(ID);
        user.setAlgoHash(algoHash);
        user.setMSID(MSID);
        
        System.out.println("2- msid, N, h(msid, id, N) envoyé au utlisateur ");
        affichage =affichage+"\n"+"2- msid, N, h(msid, id, N) envoyé au utlisateur ";
        while(msg2 == '0') {
        	System.out.println(" ");
        }
        if (msg2 == 'f') {
        	affichage = affichage + "\n"+"connxion echoué";
        	return affichage;
        }
        //recevoir les messages
        while(Z==0){
            System.out.print(" "); 
        }
        System.out.println(" - message 10 reçu (N, Z, S, h(id, N, W))");
        affichage = affichage + "\n" + " - message 10 reçu (N, Z, S, h(id, N, W))";
        
        
            //N,Z,S,h(id,N,W) reçu
            
            String h1=null,h2=null;
            W= Z ^ S;
            h1=H(ID+" "+N1+" "+W,algoHash);
            h2=H(ID+" "+N+" "+W,algoHash);
            if(h1.equals(h2)){
            	user.setMsg10('v');
                k1= N ^ S;
                k2= N ^ W;
                //k = f(enc(k1+k2),X))
                AES aes = new AES();
                k = aes.encrypt(k1+""+k2, X);
                k = H(k,algoHash);
            System.out.println("h vérifié et voci la clé de chiffrement "+"\n"+"K1 = "+k1+"\n"+"k2 = "+k2+"\n"+"k = "+k);
            affichage = affichage + "\n" + "h vérifié et voci la clé de chiffrement "+"\n"+"K1 = "+k1+"\n"+"k2 = "+k2+"\n"+"k = "+k;
            
        }else {
        	user.setMsg10('f');
            System.out.println("Connextion a echoué");
            affichage = affichage + "\n"+ "connection a echoué (h calculé et h reçu ne sont pas eguaux)";
            return affichage;
            }
            return affichage;
    }
    
    private String H(String clear, String algoHash) {
        String generatedHash = null;
        if (algoHash.equals("md5")) {
        	generatedHash = HASHES.md5Hash(clear);
        }else if (algoHash.equals("SHA-1") || algoHash.equals("SHA-256") || algoHash.equals("SHA-384") || algoHash.equals("SHA-512")) {
        	generatedHash = HASHES.shaHash(clear);
        }else if(algoHash.equals("PBKDF2")) {
        	generatedHash = HASHES.PBKDF2Hash(clear);
        }
        return generatedHash;
    }
    
    
    public static void main(String []args){
        
       /*System.out.println(new Capteur("hello","MD5","hello").H("hello","SHA-1"));
       String reçu=null;
       long t= System.currentTimeMillis();
       long time=t;
       //t=t+600000;
       t=t+10000;
       System.out.println("time= "+time);
       System.out.println("t= "+t);
       while(time < t){
           time = System.currentTimeMillis();
           //System.out.println(time);
        //wait
       }
       */
       //Utilisateur user= new Utilisateur("uid","upswd");
       //user.enregistrement("127.0.0.1", 5000);
        
       
      // System.out.println(client.exit);
      JTextArea field= new JTextArea();
    //    Utilisateur user= new Utilisateur("hello","hello","hi",1,"hi");
        //Capteur cap = new Capteur("hello","MD5","hi",salt);
      //  Thread t2 = new Thread(new Pas_thread(pas,cap,user,'a',field));
       // t2.start();
        
    }

    public String enregMsg1 (Passerelle pas){
        String affichage = null;
        
        // envoyer le  id, hashAlgo, X au passerelle
        pas.setId(ID);
        pas.setHashAlgo(algoHash);
        pas.setX(X);
        System.out.println("1- le capteur a envoyé id, algorithme de hashage et la clé secrète au passerelle");
        affichage= "1- le capteur a envoyé id, algorithme de hashage et la clé secrète au passerelle";
        return affichage;
    }
    public String enregMsg6 (Passerelle pas) {
        String affichage = null;
        System.out.println("capteur"+cap_finished);
        affichage = "  - message '"+cap_finished+"' reçu l'enregistrement est terminé";
        return affichage;
    }
    

    String authMsg1(Utilisateur user) {
        String affichage = null;
        String h=null;
        N1=0;
        Random r = new Random();
        while (N1 <= 0) {
        	N1 = r.nextLong();	
        }
        affichage ="1- N généré"+"\n"+"  - N = "+N1;
        
        
        return affichage;
    }

    String authMsg2(Utilisateur user) {
        String affichage = null;
        String h = null;
        MSID=H(ID+X,algoHash);
        h=H(MSID+ID+N1,algoHash);
        
        System.out.println("h(msid,id,n,algohash) = h("+MSID+" , "+ID+" , "+N1+" , "+algoHash+" = \n "+h);
        user.setN(N1);
        user.setReceived_h(h);
        //user.setID(ID);
        user.setAlgoHash(algoHash);
        user.setMSID(MSID);
        System.out.println("2- msid, N, h() envoyé au utlisateur ");
        affichage = "2- msid, N, h() envoyé au utlisateur ";
        return affichage;
    }

    String authMsg10(Utilisateur user) {
        String affichage = null;
        System.out.println("  - message 12 reçu (N, Z, S, h(id, N, W))");
        affichage  = "  - message 12 reçu (N, Z, S, h())";
        
        return affichage;
    }

    String authMsg12(Utilisateur user) {
        String affichage = null;
        String h1=null,h2=null;
            W= Z ^ S;
            h1=H(ID+" "+N1+" "+W,algoHash);
            h2=H(ID+" "+N+" "+W,algoHash);
            if(h1.equals(h2)){
            	user.setMsg10('v');
                k1= N ^ S;
                k2= N ^ W;
                //k = f(enc(k1+k2),X))
                System.out.println("user k1 = "+k1+"  k2 = "+k2+"   X = "+X);

                AES aes = new AES();
                k = aes.encrypt(k1+""+k2, X);
                k = H(k,"md5");
            System.out.println("14 - h vérifié et voci la clé de chiffrement "+"\n"+"K1 = "+k1+"\n"+"k2 = "+k2+"\n"+"k = "+k);
            affichage = "14- h vérifié, clé de chiffrement 'k' calculé: "+"\n"+"  - K1 = "+k1+"\n"+"  - k2 = "+k2+"\n"+"  - k = "+k;
            
        } else return "connexion éhoué"; 
        return affichage;
    }
    
    
    
    
}
