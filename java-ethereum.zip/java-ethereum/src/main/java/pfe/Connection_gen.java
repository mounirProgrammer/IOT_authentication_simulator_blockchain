package pfe;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameterName;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.FastRawTransactionManager;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.DefaultGasProvider;

import javax.swing.JTextArea;
import io.kauri.tutorials.java_ethereum.Connection;

public class Connection_gen {
	
	String address;
	Connexion contract;
	JTextArea area;
	String listening = null;

	public void create_con (String id,String X,String hashAlgo,String msid,String uid,String upswd) {
		try {
			contract.setIdentifiers(id, X, hashAlgo, msid, uid, upswd).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public String getAdresse () {
		return contract.getContractAddress();
	}
	
	public String getHashAlgo (String msid) {
		String algo= null;
		try {
			algo =contract.getHashAlgo(msid).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return algo;
		
	}
	public String getID (String msid) {
		String id= null;
		try {
			id =contract.getID(msid).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
		
	}
	public String getX (String msid) {
		String X = null;
		try {
			X =contract.getX(msid).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return X;
		
	}
	public String getUid (String msid) {
		String uid= null;
		try {
			uid =contract.getUid(msid).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return uid;
		
	}
	public String getUpswd (String  msid) {
		String upswd= null;
		try {
			upswd =contract.getUpswd(msid).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return upswd;
		
	}
	public void tolisten(String id, String uid) {
		System.out.println("Nouvelle opération d'enregistrement a été effectuée : \n Le capteur : "+id+" a été enregistré avec l'utilisateur : "+uid);
		/*if (listening.equals(null)) {
			System.out.println("listening = null");
			listening = "Nouvelle opération d'enregistrement a été effectuée : \n Le capteur : "+id+" a été enregistré avec l'utilisateur : "+uid;
			area.setText(listening);
		}else {*/
			listening = area.getText();
			listening = listening +"\n"+"Enregistrement : "+"\n"+"Nouvelle opération d'enregistrement a été effectuée : "+"\n"+"Le capteur : "+id+" a été enregistré avec l'utilisateur : "+uid; 
			area.setText(listening);
		
		//}*/
	}
	
	
	public Connection_gen (String address,JTextArea area) {
		this.area = area;
		this.address=address;
		Web3j web3 = Web3j.build(new HttpService("http://localhost:8545"));
		Credentials creds = Credentials.create(address);

		TransactionManager txManager = new FastRawTransactionManager(web3, creds);


		try {
			contract = Connexion.deploy(web3, txManager,new  DefaultGasProvider()).send();
			System.out.println(contract.getContractAddress());
			
			
			contract.createEventFlowable(DefaultBlockParameterName.EARLIEST, DefaultBlockParameterName.LATEST).subscribe(event -> {
	            final String id = event.id;
	            final String hashAlgo = event.hashAlgo;
	            final String X = event.X;
	            final String msid = event.msid.toString();
	            final String uid = event.uid;
	            final String upswd = event.upswd;
	           
	            tolisten(id,uid);

	            //Perform processing based on event values
	            
	        });
			
			
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static void main(String []args) {
		Connection_gen  generated= new Connection_gen("0x90a4ccc8d22caa6e8a165fb6febff28bc02cf7d37bd9d798bd841b101a2d0e8d",new JTextArea());
		generated.create_con("hello","hi","md5","mo","uid","upswd");
		System.out.println(generated.getHashAlgo("mo"));
		System.out.println(generated.getID("mo"));
		System.out.println(generated.getX("mo"));

	}

}
