package pfe;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Collections;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Function;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.RemoteCall;
//import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.8.4.
 */
@SuppressWarnings("rawtypes")
public class Cap_acc extends Contract {
    public static final String BINARY = "608060405234801561001057600080fd5b50610516806100206000396000f3fe608060405234801561001057600080fd5b506004361061005d577c010000000000000000000000000000000000000000000000000000000060003504632cb07402811461006257806397de0f0814610077578063a3bf241f146100a0575b600080fd5b61007561007036600461035e565b6100b3565b005b61008a610085366004610323565b610124565b60405161009791906103fe565b60405180910390f35b61008a6100ae366004610323565b6101d5565b816000846040516100c491906103e2565b908152602001604051809103902060000190805190602001906100e8929190610203565b50806000846040516100fa91906103e2565b9081526020016040518091039020600101908051906020019061011e929190610203565b50505050565b606060008260405161013691906103e2565b90815260405190819003602001902080546101509061045d565b80601f016020809104026020016040519081016040528092919081815260200182805461017c9061045d565b80156101c95780601f1061019e576101008083540402835291602001916101c9565b820191906000526020600020905b8154815290600101906020018083116101ac57829003601f168201915b50505050509050919050565b60606000826040516101e791906103e2565b908152602001604051809103902060010180546101509061045d565b82805461020f9061045d565b90600052602060002090601f0160209004810192826102315760008555610277565b82601f1061024a57805160ff1916838001178555610277565b82800160010185558215610277579182015b8281111561027757825182559160200191906001019061025c565b50610283929150610287565b5090565b5b808211156102835760008155600101610288565b600082601f8301126102ac578081fd5b813567ffffffffffffffff808211156102c7576102c76104b1565b604051601f8301601f19908116603f011681019082821181831017156102ef576102ef6104b1565b81604052838152866020858801011115610307578485fd5b8360208701602083013792830160200193909352509392505050565b600060208284031215610334578081fd5b813567ffffffffffffffff81111561034a578182fd5b6103568482850161029c565b949350505050565b600080600060608486031215610372578182fd5b833567ffffffffffffffff80821115610389578384fd5b6103958783880161029c565b945060208601359150808211156103aa578384fd5b6103b68783880161029c565b935060408601359150808211156103cb578283fd5b506103d88682870161029c565b9150509250925092565b600082516103f4818460208701610431565b9190910192915050565b602081526000825180602084015261041d816040850160208701610431565b601f01601f19169190910160400192915050565b60005b8381101561044c578181015183820152602001610434565b8381111561011e5750506000910152565b60028104600182168061047157607f821691505b602082108114156104ab577f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b50919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fdfea2646970667358221220dadfa8b169284ecf9ee6d24931f752b5f089d64094b9a5a608d97a1b51336c2264736f6c63430008040033";

    public static final String FUNC_CREATE_USER = "create_user";

    public static final String FUNC_GETHASHALGO = "getHashAlgo";

    public static final String FUNC_GETX = "getX";

    @Deprecated
    protected Cap_acc(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Cap_acc(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Cap_acc(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Cap_acc(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public RemoteCall<TransactionReceipt> create_user(String id, String _X, String _hashAlgo) {
        final Function function = new Function(
                FUNC_CREATE_USER, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id), 
                new org.web3j.abi.datatypes.Utf8String(_X), 
                new org.web3j.abi.datatypes.Utf8String(_hashAlgo)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> getHashAlgo(String id) {
        final Function function = new Function(FUNC_GETHASHALGO, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getX(String id) {
        final Function function = new Function(FUNC_GETX, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(id)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    @Deprecated
    public static Cap_acc load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Cap_acc(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Cap_acc load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Cap_acc(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Cap_acc load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Cap_acc(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Cap_acc load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Cap_acc(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Cap_acc> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Cap_acc.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Cap_acc> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Cap_acc.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    public static RemoteCall<Cap_acc> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Cap_acc.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Cap_acc> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Cap_acc.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }
}
