package pfe;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.FastRawTransactionManager;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.DefaultGasProvider;

public class Cap_gen {
	
	String address_blockchain;
	Cap_acc contract;
	
	public Cap_gen (String address_blockchain) {
		this.address_blockchain=address_blockchain;
		Credentials creds = Credentials.create(address_blockchain);
		Web3j web3 = Web3j.build(new HttpService("http://localhost:8545"));
		TransactionManager txManager = new FastRawTransactionManager(web3, creds);

		try {
			contract = Cap_acc.deploy(web3, txManager,new  DefaultGasProvider()).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void create_cap(String id, String X, String algoHash) {
		try {
			contract.create_user(id, X, algoHash).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String getX (String id) {
		String X = null;
		try {
			X= contract.getX(id).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return X;
	}
	public String getHashAlgo (String id) {
		String hashAlgo=null;
		try {
			hashAlgo = contract.getHashAlgo(id).send();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return hashAlgo;
	}
	public static void main (String [] args) {
		Cap_gen cap_gen = new Cap_gen("0x18a17289b80e7ab5ed3855b723ddba36916421466f4dc5e8ea2c7ecd1e570a5d");
		cap_gen.create_cap("hi", "hello", "kkklmd");
		System.out.println(cap_gen.getX("hi"));
	}
}
