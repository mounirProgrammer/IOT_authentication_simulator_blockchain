package org.web3j.generated.contracts;

import io.reactivex.Flowable;
import io.reactivex.functions.Function;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.ens.contracts.generated.PublicResolver.ABIChangedEventResponse;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteCall;
//import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.request.EthFilter;
//import org.web3j.protocol.core.methods.response.BaseEventResponse;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.8.4.
 */
@SuppressWarnings("rawtypes")
public class Connection extends Contract {
    public static final String BINARY = "60c0604052600660808190527f73746f726564000000000000000000000000000000000000000000000000000060a090815262000040916002919062000067565b503480156200004e57600080fd5b5060008054600160a060020a031916331790556200010c565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f10620000aa57805160ff1916838001178555620000da565b82800160010185558215620000da579182015b82811115620000da578251825591602001919060010190620000bd565b50620000e8929150620000ec565b5090565b6200010991905b80821115620000e85760008155600101620000f3565b90565b61132c806200011c6000396000f3fe608060405234801561001057600080fd5b50600436106100b0576000357c010000000000000000000000000000000000000000000000000000000090048063a3bf241f11610083578063a3bf241f146105e0578063a99dca3f14610686578063cdce187b1461068e578063e1f7ec5a14610734578063e6e862471461073c576100b0565b8063586bbfcf146100b55780635f6294711461037957806370aca6c81461049457806397de0f081461053a575b600080fd5b610377600480360360a08110156100cb57600080fd5b8101906020810181356401000000008111156100e657600080fd5b8201836020820111156100f857600080fd5b8035906020019184600183028401116401000000008311171561011a57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929594936020810193503591505064010000000081111561016d57600080fd5b82018360208201111561017f57600080fd5b803590602001918460018302840111640100000000831117156101a157600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092959493602081019350359150506401000000008111156101f457600080fd5b82018360208201111561020657600080fd5b8035906020019184600183028401116401000000008311171561022857600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929594936020810193503591505064010000000081111561027b57600080fd5b82018360208201111561028d57600080fd5b803590602001918460018302840111640100000000831117156102af57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929594936020810193503591505064010000000081111561030257600080fd5b82018360208201111561031457600080fd5b8035906020019184600183028401116401000000008311171561033657600080fd5b91908080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152509295506107e2945050505050565b005b61041f6004803603602081101561038f57600080fd5b8101906020810181356401000000008111156103aa57600080fd5b8201836020820111156103bc57600080fd5b803590602001918460018302840111640100000000831117156103de57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610d85945050505050565b6040805160208082528351818301528351919283929083019185019080838360005b83811015610459578181015183820152602001610441565b50505050905090810190601f1680156104865780820380516001836020036101000a031916815260200191505b509250505060405180910390f35b61041f600480360360208110156104aa57600080fd5b8101906020810181356401000000008111156104c557600080fd5b8201836020820111156104d757600080fd5b803590602001918460018302840111640100000000831117156104f957600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610e7c945050505050565b61041f6004803603602081101561055057600080fd5b81019060208101813564010000000081111561056b57600080fd5b82018360208201111561057d57600080fd5b8035906020019184600183028401116401000000008311171561059f57600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610f3c945050505050565b61041f600480360360208110156105f657600080fd5b81019060208101813564010000000081111561061157600080fd5b82018360208201111561062357600080fd5b8035906020019184600183028401116401000000008311171561064557600080fd5b91908080601f016020809104026020016040519081016040528093929190818152602001838380828437600092019190915250929550610ffd945050505050565b61041f6110bd565b610377600480360360208110156106a457600080fd5b8101906020810181356401000000008111156106bf57600080fd5b8201836020820111156106d157600080fd5b803590602001918460018302840111640100000000831117156106f357600080fd5b91908080601f0160208091040260200160405190810160405280939291908181526020018383808284376000920191909152509295506110f5945050505050565b61041f61110c565b61041f6004803603602081101561075257600080fd5b81019060208101813564010000000081111561076d57600080fd5b82018360208201111561077f57600080fd5b803590602001918460018302840111640100000000831117156107a157600080fd5b91908080601f01602080910402602001604051908101604052809392919081815260200183838082843760009201919091525092955061119f945050505050565b60005473ffffffffffffffffffffffffffffffffffffffff16331461080657600080fd5b6060859050856001826040518082805190602001908083835b6020831061083e5780518252601f19909201916020918201910161081f565b51815160209384036101000a6000190180199092169116179052920194855250604051938490038101909320845161087f959194919091019250905061125f565b50846001826040518082805190602001908083835b602083106108b35780518252601f199092019160209182019101610894565b6001836020036101000a038019825116818451168082178552505050505050905001915050908152602001604051809103902060010190805190602001906108fc92919061125f565b50836001826040518082805190602001908083835b602083106109305780518252601f199092019160209182019101610911565b51815160209384036101000a6000190180199092169116179052920194855250604051938490038101909320845161097595600290920194919091019250905061125f565b50806001826040518082805190602001908083835b602083106109a95780518252601f19909201916020918201910161098a565b51815160209384036101000a600019018019909216911617905292019485525060405193849003810190932084516109ee95600390920194919091019250905061125f565b50826001826040518082805190602001908083835b60208310610a225780518252601f199092019160209182019101610a03565b51815160209384036101000a60001901801990921691161790529201948552506040519384900381019093208451610a6795600490920194919091019250905061125f565b50816001826040518082805190602001908083835b60208310610a9b5780518252601f199092019160209182019101610a7c565b51815160209384036101000a60001901801990921691161790529201948552506040519384900381019093208451610ae095600590920194919091019250905061125f565b507fb0c004b083bdeb3a923635eb7aeaf1b6af835b070b573ce3efb607a9ee85e51e8686868487876040518080602001806020018060200180602001806020018060200187810387528d818151815260200191508051906020019080838360005b83811015610b59578181015183820152602001610b41565b50505050905090810190601f168015610b865780820380516001836020036101000a031916815260200191505b5087810386528c5181528c516020918201918e019080838360005b83811015610bb9578181015183820152602001610ba1565b50505050905090810190601f168015610be65780820380516001836020036101000a031916815260200191505b5087810385528b5181528b516020918201918d019080838360005b83811015610c19578181015183820152602001610c01565b50505050905090810190601f168015610c465780820380516001836020036101000a031916815260200191505b5087810384528a5181528a516020918201918c019080838360005b83811015610c79578181015183820152602001610c61565b50505050905090810190601f168015610ca65780820380516001836020036101000a031916815260200191505b5087810383528951815289516020918201918b019080838360005b83811015610cd9578181015183820152602001610cc1565b50505050905090810190601f168015610d065780820380516001836020036101000a031916815260200191505b5087810382528851815288516020918201918a019080838360005b83811015610d39578181015183820152602001610d21565b50505050905090810190601f168015610d665780820380516001836020036101000a031916815260200191505b509c5050505050505050505050505060405180910390a1505050505050565b60606001826040518082805190602001908083835b60208310610db95780518252601f199092019160209182019101610d9a565b518151600019602094850361010090810a820192831692199390931691909117909252949092019687526040805197889003820188206005018054601f6002600183161590980290950116959095049283018290048202880182019052818752929450925050830182828015610e705780601f10610e4557610100808354040283529160200191610e70565b820191906000526020600020905b815481529060010190602001808311610e5357829003601f168201915b50505050509050919050565b60606001826040518082805190602001908083835b60208310610eb05780518252601f199092019160209182019101610e91565b518151600019602094850361010090810a820192831692199390931691909117909252949092019687526040805197889003820188206003018054601f6002600183161590980290950116959095049283018290048202880182019052818752929450925050830182828015610e705780601f10610e4557610100808354040283529160200191610e70565b60606001826040518082805190602001908083835b60208310610f705780518252601f199092019160209182019101610f51565b518151600019602094850361010090810a8201928316921993909316919091179092529490920196875260408051978890038201882060019081018054601f60029382161590980290950190941604948501829004820288018201905283875290945091925050830182828015610e705780601f10610e4557610100808354040283529160200191610e70565b60606001826040518082805190602001908083835b602083106110315780518252601f199092019160209182019101611012565b518151600019602094850361010090810a8201928316921993909316919091179092529490920196875260408051978890038201882060029081018054601f600182161590980290950190941604948501829004820288018201905283875290945091925050830182828015610e705780601f10610e4557610100808354040283529160200191610e70565b60408051808201909152600b81527f68656c6c6f20776f726c6400000000000000000000000000000000000000000060208201525b90565b805161110890600290602084019061125f565b5050565b60028054604080516020601f60001961010060018716150201909416859004938401819004810282018101909252828152606093909290918301828280156111955780601f1061116a57610100808354040283529160200191611195565b820191906000526020600020905b81548152906001019060200180831161117857829003601f168201915b5050505050905090565b60606001826040518082805190602001908083835b602083106111d35780518252601f1990920191602091820191016111b4565b518151600019602094850361010090810a820192831692199390931691909117909252949092019687526040805197889003820188206004018054601f6002600183161590980290950116959095049283018290048202880182019052818752929450925050830182828015610e705780601f10610e4557610100808354040283529160200191610e70565b828054600181600116156101000203166002900490600052602060002090601f016020900481019282601f106112a057805160ff19168380011785556112cd565b828001600101855582156112cd579182015b828111156112cd5782518255916020019190600101906112b2565b506112d99291506112dd565b5090565b6110f291905b808211156112d957600081556001016112e356fea265627a7a723158208086b298e1204180c4f51dc1d3ee661a9ddab23e302f5d47909e52e2b170974564736f6c63430005110032";

    public static final String FUNC_CREATECONNECTION = "createConnection";

    public static final String FUNC_GETHASHALGO = "getHashAlgo";

    public static final String FUNC_GETID = "getID";

    public static final String FUNC_GETSTORED = "getStored";

    public static final String FUNC_GETUID = "getUid";

    public static final String FUNC_GETUPSWD = "getUpswd";

    public static final String FUNC_GETX = "getX";

    public static final String FUNC_HI = "hi";

    public static final String FUNC_SETSTORED = "setStored";

    public static final Event CREATE_EVENT = new Event("create", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
    ;

    @Deprecated
    protected Connection(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Connection(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Connection(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Connection(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public List<CreateEventResponse> getCreateEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(CREATE_EVENT, transactionReceipt);
        ArrayList<CreateEventResponse> responses = new ArrayList<CreateEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            CreateEventResponse typedResponse = new CreateEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse._id = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse._X = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse._hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.msid = (String) eventValues.getNonIndexedValues().get(3).getValue();
            typedResponse._uid = (String) eventValues.getNonIndexedValues().get(4).getValue();
            typedResponse._upswd = (String) eventValues.getNonIndexedValues().get(5).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<CreateEventResponse> createEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new Function<Log, CreateEventResponse>() {
            @Override
            public CreateEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(CREATE_EVENT, log);
                CreateEventResponse typedResponse = new CreateEventResponse();
                typedResponse.log = log;
                typedResponse._id = (String) eventValues.getNonIndexedValues().get(0).getValue();
                typedResponse._X = (String) eventValues.getNonIndexedValues().get(1).getValue();
                typedResponse._hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
                typedResponse.msid = (String) eventValues.getNonIndexedValues().get(3).getValue();
                typedResponse._uid = (String) eventValues.getNonIndexedValues().get(4).getValue();
                typedResponse._upswd = (String) eventValues.getNonIndexedValues().get(5).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<CreateEventResponse> createEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(CREATE_EVENT));
        return createEventFlowable(filter);
    }

    public RemoteCall<TransactionReceipt> createConnection(String _id, String _X, String _hashAlgo, String _uid, String _upswd) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(
                FUNC_CREATECONNECTION, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_id), 
                new org.web3j.abi.datatypes.Utf8String(_X), 
                new org.web3j.abi.datatypes.Utf8String(_hashAlgo), 
                new org.web3j.abi.datatypes.Utf8String(_uid), 
                new org.web3j.abi.datatypes.Utf8String(_upswd)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<String> getHashAlgo(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETHASHALGO, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getID(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getStored() {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETSTORED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUid(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUpswd(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUPSWD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getX(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETX, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> hi() {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_HI, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> setStored(String _stored) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(
                FUNC_SETSTORED, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_stored)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    @Deprecated
    public static Connection load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connection(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Connection load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connection(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Connection load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Connection(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Connection load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Connection(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Connection> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connection.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<Connection> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connection.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connection> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connection.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connection> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connection.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }

    public static class CreateEventResponse extends ABIChangedEventResponse {
        public String _id;

        public String _X;

        public String _hashAlgo;

        public String msid;

        public String _uid;

        public String _upswd;
    }
}