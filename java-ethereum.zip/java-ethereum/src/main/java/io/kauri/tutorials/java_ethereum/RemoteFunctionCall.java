package io.kauri.tutorials.java_ethereum;

public class RemoteFunctionCall<T> {

}
