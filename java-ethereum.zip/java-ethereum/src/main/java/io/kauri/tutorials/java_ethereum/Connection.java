package io.kauri.tutorials.java_ethereum;

import io.reactivex.Flowable;
import io.reactivex.functions.Function;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.web3j.abi.EventEncoder;
import org.web3j.abi.TypeReference;
import org.web3j.abi.datatypes.Event;
import org.web3j.abi.datatypes.Type;
import org.web3j.abi.datatypes.Utf8String;
import org.web3j.crypto.Credentials;
import org.web3j.ens.contracts.generated.PublicResolver.ABIChangedEventResponse;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.core.RemoteCall;
//import org.web3j.protocol.core.RemoteFunctionCall;
import org.web3j.protocol.core.methods.request.EthFilter;
//import org.web3j.protocol.core.methods.response.BaseEventResponse;
import org.web3j.protocol.core.methods.response.Log;
import org.web3j.protocol.core.methods.response.TransactionReceipt;
import org.web3j.tx.Contract;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.ContractGasProvider;

/**
 * <p>Auto generated code.
 * <p><strong>Do not modify!</strong>
 * <p>Please use the <a href="https://docs.web3j.io/command_line.html">web3j command line tools</a>,
 * or the org.web3j.codegen.SolidityFunctionWrapperGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 *
 * <p>Generated with web3j version 4.8.4.
 */
@SuppressWarnings("rawtypes")
public class Connection extends Contract {
    public static final String BINARY = "60c0604052600660808190527f73746f726564000000000000000000000000000000000000000000000000000060a090815261003e9160019190610063565b5034801561004b57600080fd5b5060008054600160a060020a03191633179055610150565b82805461006f906100fc565b90600052602060002090601f01602090048101928261009157600085556100d7565b82601f106100aa57805160ff19168380011785556100d7565b828001600101855582156100d7579182015b828111156100d75782518255916020019190600101906100bc565b506100e39291506100e7565b5090565b5b808211156100e357600081556001016100e8565b60028104600182168061011057607f821691505b6020821081141561014a577f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b50919050565b6109458061015f6000396000f3fe608060405234801561001057600080fd5b50600436106100bb576000357c010000000000000000000000000000000000000000000000000000000090048063a3bf241f11610083578063a3bf241f14610124578063a99dca3f14610137578063cdce187b14610170578063e1f7ec5a14610183578063e6e862471461018b57600080fd5b8063185f343e146100c05780635f629471146100e957806370aca6c8146100c05780637203d82a146100fc57806397de0f0814610111575b600080fd5b6100d36100ce366004610686565b61019e565b6040516100e091906107d5565b60405180910390f35b6100d36100f7366004610686565b610251565b61010f61010a3660046106c1565b61027f565b005b6100d361011f366004610686565b610433565b6100d3610132366004610686565b610461565b60408051808201909152600b81527f68656c6c6f20776f726c6400000000000000000000000000000000000000000060208201526100d3565b61010f61017e366004610686565b61048f565b6100d36104a6565b6100d3610199366004610686565b610538565b60606002826040516101b091906107b9565b908152602001604051809103902060030180546101cc9061088c565b80601f01602080910402602001604051908101604052809291908181526020018280546101f89061088c565b80156102455780601f1061021a57610100808354040283529160200191610245565b820191906000526020600020905b81548152906001019060200180831161022857829003601f168201915b50505050509050919050565b606060028260405161026391906107b9565b908152602001604051809103902060050180546101cc9061088c565b60005473ffffffffffffffffffffffffffffffffffffffff1633146102a357600080fd5b6060859050856002826040516102b991906107b9565b908152602001604051809103902060000190805190602001906102dd929190610566565b50846002826040516102ef91906107b9565b90815260200160405180910390206001019080519060200190610313929190610566565b508360028260405161032591906107b9565b90815260200160405180910390206002019080519060200190610349929190610566565b508060028260405161035b91906107b9565b9081526020016040518091039020600301908051906020019061037f929190610566565b508260028260405161039191906107b9565b908152602001604051809103902060040190805190602001906103b5929190610566565b50816002826040516103c791906107b9565b908152602001604051809103902060050190805190602001906103eb929190610566565b507fd660688b1ec12baaa13ac37407af931386611a2d7f6a4eb6f277c6c8306ffabd86868686866040516104239594939291906107ef565b60405180910390a1505050505050565b606060028260405161044591906107b9565b908152602001604051809103902060010180546101cc9061088c565b606060028260405161047391906107b9565b908152602001604051809103902060020180546101cc9061088c565b80516104a2906001906020840190610566565b5050565b6060600180546104b59061088c565b80601f01602080910402602001604051908101604052809291908181526020018280546104e19061088c565b801561052e5780601f106105035761010080835404028352916020019161052e565b820191906000526020600020905b81548152906001019060200180831161051157829003601f168201915b5050505050905090565b606060028260405161054a91906107b9565b908152602001604051809103902060040180546101cc9061088c565b8280546105729061088c565b90600052602060002090601f01602090048101928261059457600085556105da565b82601f106105ad57805160ff19168380011785556105da565b828001600101855582156105da579182015b828111156105da5782518255916020019190600101906105bf565b506105e69291506105ea565b5090565b5b808211156105e657600081556001016105eb565b600082601f83011261060f578081fd5b813567ffffffffffffffff8082111561062a5761062a6108e0565b604051601f8301601f19908116603f01168101908282118183101715610652576106526108e0565b8160405283815286602085880101111561066a578485fd5b8360208701602083013792830160200193909352509392505050565b600060208284031215610697578081fd5b813567ffffffffffffffff8111156106ad578182fd5b6106b9848285016105ff565b949350505050565b600080600080600060a086880312156106d8578081fd5b853567ffffffffffffffff808211156106ef578283fd5b6106fb89838a016105ff565b96506020880135915080821115610710578283fd5b61071c89838a016105ff565b95506040880135915080821115610731578283fd5b61073d89838a016105ff565b94506060880135915080821115610752578283fd5b61075e89838a016105ff565b93506080880135915080821115610773578283fd5b50610780888289016105ff565b9150509295509295909350565b600081518084526107a581602086016020860161085c565b601f01601f19169290920160200192915050565b600082516107cb81846020870161085c565b9190910192915050565b6020815260006107e8602083018461078d565b9392505050565b60a08152600061080260a083018861078d565b8281036020840152610814818861078d565b90508281036040840152610828818761078d565b9050828103606084015261083c818661078d565b90508281036080840152610850818561078d565b98975050505050505050565b60005b8381101561087757818101518382015260200161085f565b83811115610886576000848401525b50505050565b6002810460018216806108a057607f821691505b602082108114156108da577f4e487b7100000000000000000000000000000000000000000000000000000000600052602260045260246000fd5b50919050565b7f4e487b7100000000000000000000000000000000000000000000000000000000600052604160045260246000fdfea264697066735822122067555fe301694d4fd56b870ac9500633482cb78b96871cb9d88f3c09b2ded62864736f6c63430008040033";

    public static final String FUNC_GETHASHALGO = "getHashAlgo";

    public static final String FUNC_GETID = "getID";

    public static final String FUNC_GETMSID = "getMsid";

    public static final String FUNC_GETSTORED = "getStored";

    public static final String FUNC_GETUID = "getUid";

    public static final String FUNC_GETUPSWD = "getUpswd";

    public static final String FUNC_GETX = "getX";

    public static final String FUNC_HI = "hi";

    public static final String FUNC_SETIDENTIFIERS = "setIdentifiers";

    public static final String FUNC_SETSTORED = "setStored";

    public static final Event SETTINGIDENTIFIERS_EVENT = new Event("SettingIdentifiers", 
            Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}, new TypeReference<Utf8String>() {}));
    ;

    @Deprecated
    protected Connection(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    protected Connection(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, credentials, contractGasProvider);
    }

    @Deprecated
    protected Connection(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        super(BINARY, contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    protected Connection(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        super(BINARY, contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public List<SettingIdentifiersEventResponse> getSettingIdentifiersEvents(TransactionReceipt transactionReceipt) {
        List<Contract.EventValuesWithLog> valueList = extractEventParametersWithLog(SETTINGIDENTIFIERS_EVENT, transactionReceipt);
        ArrayList<SettingIdentifiersEventResponse> responses = new ArrayList<SettingIdentifiersEventResponse>(valueList.size());
        for (Contract.EventValuesWithLog eventValues : valueList) {
            SettingIdentifiersEventResponse typedResponse = new SettingIdentifiersEventResponse();
            typedResponse.log = eventValues.getLog();
            typedResponse.id = (String) eventValues.getNonIndexedValues().get(0).getValue();
            typedResponse.X = (String) eventValues.getNonIndexedValues().get(1).getValue();
            typedResponse.hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
            typedResponse.uid = (String) eventValues.getNonIndexedValues().get(3).getValue();
            typedResponse.upswd = (String) eventValues.getNonIndexedValues().get(4).getValue();
            responses.add(typedResponse);
        }
        return responses;
    }

    public Flowable<SettingIdentifiersEventResponse> settingIdentifiersEventFlowable(EthFilter filter) {
        return web3j.ethLogFlowable(filter).map(new Function<Log, SettingIdentifiersEventResponse>() {
            @Override
            public SettingIdentifiersEventResponse apply(Log log) {
                Contract.EventValuesWithLog eventValues = extractEventParametersWithLog(SETTINGIDENTIFIERS_EVENT, log);
                SettingIdentifiersEventResponse typedResponse = new SettingIdentifiersEventResponse();
                typedResponse.log = log;
                typedResponse.id = (String) eventValues.getNonIndexedValues().get(0).getValue();
                typedResponse.X = (String) eventValues.getNonIndexedValues().get(1).getValue();
                typedResponse.hashAlgo = (String) eventValues.getNonIndexedValues().get(2).getValue();
                typedResponse.uid = (String) eventValues.getNonIndexedValues().get(3).getValue();
                typedResponse.upswd = (String) eventValues.getNonIndexedValues().get(4).getValue();
                return typedResponse;
            }
        });
    }

    public Flowable<SettingIdentifiersEventResponse> settingIdentifiersEventFlowable(DefaultBlockParameter startBlock, DefaultBlockParameter endBlock) {
        EthFilter filter = new EthFilter(startBlock, endBlock, getContractAddress());
        filter.addSingleTopic(EventEncoder.encode(SETTINGIDENTIFIERS_EVENT));
        return settingIdentifiersEventFlowable(filter);
    }

    public RemoteCall<String> getHashAlgo(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETHASHALGO, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getID(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getMsid(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETMSID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getStored() {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETSTORED, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUid(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUID, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getUpswd(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETUPSWD, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> getX(String msid) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_GETX, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(msid)), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<String> hi() {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(FUNC_HI, 
                Arrays.<Type>asList(), 
                Arrays.<TypeReference<?>>asList(new TypeReference<Utf8String>() {}));
        return executeRemoteCallSingleValueReturn(function, String.class);
    }

    public RemoteCall<TransactionReceipt> setIdentifiers(String _id, String _X, String _hashAlgo, String _uid, String _upswd) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(
                FUNC_SETIDENTIFIERS, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_id), 
                new org.web3j.abi.datatypes.Utf8String(_X), 
                new org.web3j.abi.datatypes.Utf8String(_hashAlgo), 
                new org.web3j.abi.datatypes.Utf8String(_uid), 
                new org.web3j.abi.datatypes.Utf8String(_upswd)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    public RemoteCall<TransactionReceipt> setStored(String _stored) {
        final org.web3j.abi.datatypes.Function function = new org.web3j.abi.datatypes.Function(
                FUNC_SETSTORED, 
                Arrays.<Type>asList(new org.web3j.abi.datatypes.Utf8String(_stored)), 
                Collections.<TypeReference<?>>emptyList());
        return executeRemoteCallTransaction(function);
    }

    @Deprecated
    public static Connection load(String contractAddress, Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connection(contractAddress, web3j, credentials, gasPrice, gasLimit);
    }

    @Deprecated
    public static Connection load(String contractAddress, Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return new Connection(contractAddress, web3j, transactionManager, gasPrice, gasLimit);
    }

    public static Connection load(String contractAddress, Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return new Connection(contractAddress, web3j, credentials, contractGasProvider);
    }

    public static Connection load(String contractAddress, Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return new Connection(contractAddress, web3j, transactionManager, contractGasProvider);
    }

    public static RemoteCall<Connection> deploy(Web3j web3j, Credentials credentials, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connection.class, web3j, credentials, contractGasProvider, BINARY, "");
    }

    public static RemoteCall<Connection> deploy(Web3j web3j, TransactionManager transactionManager, ContractGasProvider contractGasProvider) {
        return deployRemoteCall(Connection.class, web3j, transactionManager, contractGasProvider, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connection> deploy(Web3j web3j, Credentials credentials, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connection.class, web3j, credentials, gasPrice, gasLimit, BINARY, "");
    }

    @Deprecated
    public static RemoteCall<Connection> deploy(Web3j web3j, TransactionManager transactionManager, BigInteger gasPrice, BigInteger gasLimit) {
        return deployRemoteCall(Connection.class, web3j, transactionManager, gasPrice, gasLimit, BINARY, "");
    }

    public static class SettingIdentifiersEventResponse extends ABIChangedEventResponse {
        public String id;

        public String X;

        public String hashAlgo;

        public String uid;

        public String upswd;
    }
}