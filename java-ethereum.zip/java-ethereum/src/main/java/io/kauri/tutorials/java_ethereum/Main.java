package io.kauri.tutorials.java_ethereum;

import java.io.IOException;
import java.util.Scanner;

import org.web3j.crypto.Credentials;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;
import org.web3j.tx.FastRawTransactionManager;
import org.web3j.tx.TransactionManager;
import org.web3j.tx.gas.DefaultGasProvider;
import org.web3j.protocol.core.methods.response.EthBlockNumber;
import org.web3j.protocol.core.methods.response.EthGasPrice;
import org.web3j.protocol.core.methods.response.Web3ClientVersion;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				Web3j web3 = Web3j.build(new HttpService("http://localhost:8545"));
				System.out.println("Successfuly connected to Ethereum");

			    try {
			      // web3_clientVersion returns the current client version.
			      Web3ClientVersion clientVersion = web3.web3ClientVersion().send();

			      // eth_blockNumber returns the number of most recent block.
			      EthBlockNumber blockNumber = web3.ethBlockNumber().send();

			      // eth_gasPrice, returns the current price per gas in wei.
			      EthGasPrice gasPrice = web3.ethGasPrice().send();
			      

			      // Print result
			      System.out.println("Client version: " + clientVersion.getWeb3ClientVersion());
			      System.out.println("Block number: " + blockNumber.getBlockNumber());
			      System.out.println("Gas price: " + gasPrice.getGasPrice());

			    } catch (IOException ex) {
			      throw new RuntimeException("Error whilst sending json-rpc requests", ex);
			    }

				Credentials creds = Credentials.create("0xff437da67516d8b63382ac1f7fdb01dcbe8591f4b21f782da32530ac9b121f4a");
				TransactionManager txManager = new FastRawTransactionManager(web3, creds);

				try {
					Connection contract = Connection.deploy(web3, txManager,new  DefaultGasProvider()).send();
					Scanner sc =new Scanner(System.in);
					String id = null, X = null, hashAlgo = null, msid = null, uid = null, upswd = null;
					System.out.println("give id");
					id=sc.next();
					System.out.println("give X");
					X=sc.next();
					System.out.println("give algo");
					hashAlgo=sc.next();
					System.out.println("give uid");
					uid = sc.next();
					System.out.println("give upswd");
					upswd=sc.next();
					contract.setIdentifiers(id, X, hashAlgo, uid, upswd).send();
					System.out.println(contract.getID(id).send());
					/*
					String hello = contract.hi().send();
					System.out.println(hello);
					System.out.println("give stored");
					contract.setStored(sc.next()).send();
					hello = contract.getStored().send();
					System.out.println(hello);
					*/
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
