package interfaces;

public class Sensor {
	String id;
	String X;
	String algoHash;
	String passerelle;
	boolean enr;
	boolean auth;
	String ip;
	
	public Sensor(String id,String X,String hashAlgo,String ip,boolean enr, boolean auth) {
		this.X=X;
		this.algoHash=hashAlgo;
		this.id=id;
		this.ip=ip;
		this.enr=enr;
		this.auth=auth;
	}

}
