package interfaces;

public class Gateway {
	String ip = "127.0.0.1";
	String blockchain = null;
	pfe.Connection_gen generator;
	
	
	public Gateway (String ip,String blockchain, pfe.Connection_gen generator) {
		this.ip=ip;
		this.blockchain=blockchain;
		this.generator = generator;
		
	}

}
